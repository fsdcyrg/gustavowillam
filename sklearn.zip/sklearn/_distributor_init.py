
'''
Helper to preload the OpenMP dll to prevent "dll not found"
errors.
Once a DLL is preloaded, its namespace is made available to any
subsequent DLL. This file originated in the scikit-learn-wheels
github repo, and is created as part of the scripts that build the
wheel.
'''
